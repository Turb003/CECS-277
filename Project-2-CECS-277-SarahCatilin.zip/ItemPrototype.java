
public interface ItemPrototype 
{
	public ItemPrototype clone();
}
